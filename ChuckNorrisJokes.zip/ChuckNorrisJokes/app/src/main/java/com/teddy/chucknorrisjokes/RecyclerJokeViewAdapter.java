package com.teddy.chucknorrisjokes;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import es.dmoral.toasty.Toasty;

import static android.content.Context.CLIPBOARD_SERVICE;
import static androidx.core.content.ContextCompat.getSystemService;

public class RecyclerJokeViewAdapter extends RecyclerView.Adapter<RecyclerJokeViewAdapter.ViewHolder> {

    private Context context;
    private List<Joke> jokesList;
    /*private OnItemClickListener listener;


    public void setOnClickListener(OnItemClickListener vlistener)
    {
        this.listener = vlistener;
    }

    public  interface OnItemClickListener
    {
        void onItemClick(int position);
    }*/

    public RecyclerJokeViewAdapter(Context context, List<Joke> jokesList) {
        this.context = context;
        this.jokesList = jokesList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.joke_item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Joke currentJoke = jokesList.get(position);

        holder.facts.setText(currentJoke.getFact());
        holder.votes.setText(""+currentJoke.getVotes());
        holder.toCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = (String) holder.facts.getText();
                ClipboardManager clipboardManager = (ClipboardManager) context.getSystemService(CLIPBOARD_SERVICE);
                ClipData data = ClipData.newPlainText("fact", text );
                clipboardManager.setPrimaryClip(data);
                Toasty.success(context, "Texte copié avec sucèss", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return jokesList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView facts;
        private TextView votes;
        private ImageView toCopy;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            facts = itemView.findViewById(R.id.text_view_facts);
            votes = itemView.findViewById(R.id.text_view_votes);
            toCopy = itemView.findViewById(R.id.imageView_copy);
        }
    }
}
