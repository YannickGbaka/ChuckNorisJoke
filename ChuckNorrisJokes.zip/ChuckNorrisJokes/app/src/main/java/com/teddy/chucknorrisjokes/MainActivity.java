package com.teddy.chucknorrisjokes;

import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerJokeViewAdapter recyclerJokeViewAdapter;
    private RequestQueue requestQueue;
    private List<Joke> jokeList;
    private Button refrshing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        refrshing = findViewById(R.id.refresh);

        jokeList = new ArrayList<>();

        recyclerView = findViewById(R.id.recycler_joke_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        requestQueue = Volley.newRequestQueue(this);

        JsonParse();
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(jokeList.size()<=0)
                {
                    internetCheck(View.VISIBLE, "\"Vérifiez si vous avez accès à internet svp...\"");
                }
            }
        }, 3000);
        refrshing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JsonParse();
               handler.postDelayed(new Runnable() {
                   @Override
                   public void run() {
                       if(jokeList.size()<=0)
                       {
                           internetCheck(View.VISIBLE, "Vérifiez si vous avez accès à internet svp...");
                       }else {
                           internetCheck(View.INVISIBLE,"");
                       }
                   }
               }, 2000);
            }
        });
    }

    private void internetCheck(int VISIBILITY, String toastMessage)
    {
        if(VISIBILITY ==4)
        {
            refrshing.setVisibility(VISIBILITY);
        }else if(VISIBILITY == 0){
            refrshing.setVisibility(VISIBILITY);
            Toasty.warning(MainActivity.this, toastMessage, Toast.LENGTH_LONG).show();
        }
    }

    private void JsonParse() {
        String url = "http://chucknorrisfacts.fr/api/get?data=tri:top;nb:99";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject object = response.getJSONObject(i);
                                String fact = object.getString("fact");
                                fact = Html.fromHtml(fact).toString();
                                int vote = object.getInt("vote");

                                jokeList.add( new Joke(fact, vote));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        recyclerJokeViewAdapter = new RecyclerJokeViewAdapter(MainActivity.this, jokeList);
                        recyclerView.setAdapter(recyclerJokeViewAdapter);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }
}
