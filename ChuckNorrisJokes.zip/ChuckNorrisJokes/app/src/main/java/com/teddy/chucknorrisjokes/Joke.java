package com.teddy.chucknorrisjokes;

public class Joke {
   private String fact;
   private int votes;

    public Joke(String fact, int votes) {
        this.fact = fact;
        this.votes = votes;
    }

    public String getFact() {
        return fact;
    }

    public int getVotes() {
        return votes;
    }
}
